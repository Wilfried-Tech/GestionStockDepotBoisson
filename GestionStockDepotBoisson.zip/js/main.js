initSwipeMenu();
initCircularMenu();
writeOnTerminal($('#console-line'));
