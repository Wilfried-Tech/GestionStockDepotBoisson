initSwipeMenu();
initMenuClickListener();
