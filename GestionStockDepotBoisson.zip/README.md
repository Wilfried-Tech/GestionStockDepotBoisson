# Gestion Stock Depot Boisson

pour Joseph
Il faut importer le fichier sql contenu dans Database dans ton serveur 
pour modifier la base de données une fois terminé faut la exporter et remettre dans le même dossier

pour Kyliane

va dans phpadmin tu cherches importer puis tu importe le fichier sql contenu
dans le dossier ( database )

puis le tout est joué

dans le dossier ( bin ) tu peux trouver une mise a jour de application Android de ce projet