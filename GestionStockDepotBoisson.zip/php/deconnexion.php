<?php

require_once("redirection.php");

session_destroy();

header("Location: ..");